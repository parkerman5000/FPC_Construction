# FPC Construction Website

[![Version](https://img.shields.io/badge/version-1.2-gold.svg)](https://github.com/parkerman5000/FPC_Construction)
[![Powered by](https://img.shields.io/badge/powered%20by-mpowerio.ai-orange.svg)](https://mpowerio.ai)
[![License](https://img.shields.io/badge/license-MIT-blue.svg)](LICENSE)

> **North Augusta's Trusted Contractor** — Driveways, Decks, Land Clearing, Privacy Fencing, Septic Tanks, and Land Grading

🔗 **Live Site:** [parkerman5000.github.io/FPC_Construction](https://parkerman5000.github.io/FPC_Construction/)

---

## 🚀 Version 1.2 - What's New

- ✅ **Custom Logo** — Original FPC logo in header & footer
- ✅ **Google Drive Auto-Load** — Carousel loads photos from Drive automatically
- ✅ **Duplicate Detection** — No repeated images in carousel
- ✅ **Updated Services** — Land Clearing, Privacy Fencing, Septic Tank, Land Grading
- ✅ **Optimized Preloading** — Smooth image transitions

---

## 🏗️ Services

| Service | Description |
|---------|-------------|
| 🛤️ **Driveways** | Custom concrete driveways |
| 🏠 **Decks & Patios** | Outdoor living spaces ⭐ Popular |
| 🌲 **Land Clearing** | Site preparation & brush removal |
| 🔲 **Privacy Fencing** | Wood, vinyl, and composite options |
| 💧 **Septic Tank Service** | Installation, repair & maintenance |
| ⛰️ **Land Grading** | Drainage solutions & leveling |

---

## 📁 File Structure

```
FPC_Construction/
├── index.html              # Main website
├── css/
│   └── styles.css          # All styles (v1.2)
├── js/
│   ├── carousel-config.js  # Photo carousel config
│   └── main.js             # JavaScript (v1.2)
├── images/
│   ├── fpc-logo-header.jpeg  # Company logo
│   └── carousel/           # Carousel images
└── README.md
```

---

## 🎠 Carousel Configuration

### Adding Photos from Google Drive

1. Upload photos to your Google Drive
2. Right-click → Share → "Anyone with the link"
3. Copy the file ID from the link
4. Add to `js/carousel-config.js`:

```javascript
googleDriveFileIds: [
    'YOUR_FILE_ID_1',
    'YOUR_FILE_ID_2',
    // Add more IDs...
],
```

---

## 📞 Contact

**FPC Construction**  
📍 North Augusta, SC 29860  
📱 (803) 288-9616  
📧 info@fpcconstructionsc.com  
🕐 Mon-Fri: 7AM - 6PM

---

## 🛠️ Technology

- **HTML5** / **CSS3** / **JavaScript**
- **AOS** — Animate On Scroll
- **Font Awesome** — Icons
- **Google Fonts** — Bebas Neue, Inter, Playfair Display
- **ElevenLabs Convai** — AI Chat Widget

---

## 📜 Credits

**Powered by:** [mpowerio.ai](https://mpowerio.ai)  
*"Qualified Inputs yielding Quantum Outputs!"*  
*Solar Fusion level power for Small Businesses*

**Installer:** Ernesto Martinez [@digitwitch.com](https://digitwitch.com)

---

## 📋 Version History

| Version | Date | Changes |
|---------|------|---------|
| v1.2 | Jan 2026 | Custom logo, new services, Drive auto-load |
| v1.1 | Jan 2026 | Dynamic carousel, config file, video support |
| v1.0 | Jan 2026 | Initial release |

---

**TB12 Mentality — Championship Level Execution** 🏆

© 2024 FPC Construction | Built with ❤️ by mpowerio.ai
