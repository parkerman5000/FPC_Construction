# Carousel Images Directory

Upload your carousel images here if using local files instead of Google Drive.

Supported formats:
- .jpg / .jpeg
- .png
- .webp

For Google Drive images, just add file IDs to `js/carousel-config.js`

---
Powered by mpowerio.ai ⚡
