/**
 * FPC CONSTRUCTION - Elite JavaScript v1.2
 * TB12 Mentality - Championship Level Interactions
 * ============================================
 * POWERED BY: mpowerio.ai - "Qualified Inputs yielding Quantum Outputs!"
 * Solar Fusion level power for Small Businesses!
 * INSTALLER: Ernesto Martinez @digitwitch.com
 * ============================================
 * 
 * v1.2 FEATURES:
 * - Auto-load from Google Drive
 * - Duplicate detection
 * - PNG upscaling support
 * - Optimized preloading
 * ============================================
 */

// Wait for DOM to be fully loaded
document.addEventListener('DOMContentLoaded', function() {
    // Initialize all modules
    initPreloader();
    initScrollProgress();
    initNavigation();
    initDynamicCarousel(); // v1.2 - Auto-load from Google Drive
    initCounterAnimation();
    initTestimonialSlider();
    initProjectFilter();
    initFAQ();
    initContactForm();
    initBackToTop();
    initFloatingCTA();
    initSmoothScroll();
    initAOS();
});

/**
 * Preloader
 */
function initPreloader() {
    const preloader = document.getElementById('preloader');

    if (!preloader) return;

    // Hide preloader when page is loaded
    window.addEventListener('load', function() {
        setTimeout(function() {
            preloader.classList.add('hidden');
            document.body.classList.remove('no-scroll');
        }, 500);
    });

    // Fallback - hide after 3 seconds max
    setTimeout(function() {
        preloader.classList.add('hidden');
        document.body.classList.remove('no-scroll');
    }, 3000);
}

/**
 * Scroll Progress Bar
 */
function initScrollProgress() {
    const progressBar = document.querySelector('.scroll-progress');

    if (!progressBar) return;

    window.addEventListener('scroll', function() {
        const scrollTop = window.pageYOffset;
        const docHeight = document.documentElement.scrollHeight - window.innerHeight;
        const scrollPercent = (scrollTop / docHeight) * 100;
        progressBar.style.width = scrollPercent + '%';
    });
}

/**
 * Navigation
 */
function initNavigation() {
    const header = document.getElementById('header');
    const navToggle = document.getElementById('navToggle');
    const navMenu = document.getElementById('navMenu');
    const navLinks = document.querySelectorAll('.nav-link');

    if (!header) return;

    // Scroll effect for header
    window.addEventListener('scroll', function() {
        if (window.scrollY > 100) {
            header.classList.add('scrolled');
        } else {
            header.classList.remove('scrolled');
        }
    });

    // Mobile menu toggle
    if (navToggle && navMenu) {
        navToggle.addEventListener('click', function() {
            navToggle.classList.toggle('active');
            navMenu.classList.toggle('active');
            document.body.classList.toggle('no-scroll');
        });

        // Close menu when clicking a link
        navLinks.forEach(function(link) {
            link.addEventListener('click', function() {
                navToggle.classList.remove('active');
                navMenu.classList.remove('active');
                document.body.classList.remove('no-scroll');
            });
        });

        // Close menu when clicking outside
        document.addEventListener('click', function(e) {
            if (!navMenu.contains(e.target) && !navToggle.contains(e.target)) {
                navToggle.classList.remove('active');
                navMenu.classList.remove('active');
                document.body.classList.remove('no-scroll');
            }
        });
    }

    // Active link highlighting
    const sections = document.querySelectorAll('section[id]');

    window.addEventListener('scroll', function() {
        const scrollY = window.pageYOffset + 200;

        sections.forEach(function(section) {
            const sectionHeight = section.offsetHeight;
            const sectionTop = section.offsetTop;
            const sectionId = section.getAttribute('id');
            const navLink = document.querySelector('.nav-link[href="#' + sectionId + '"]');

            if (scrollY > sectionTop && scrollY <= sectionTop + sectionHeight) {
                navLinks.forEach(function(link) {
                    link.classList.remove('active');
                });
                if (navLink) navLink.classList.add('active');
            }
        });
    });
}

/**
 * v1.2 - Dynamic Hero Carousel with Google Drive Auto-Load
 * Supports both images AND video (.mp4, .webm)
 * Features: Auto-load from Drive, duplicate detection, preloading
 */
function initDynamicCarousel() {
    const carouselContainer = document.querySelector('.hero-carousel');
    const prevBtn = document.querySelector('.carousel-btn.prev');
    const nextBtn = document.querySelector('.carousel-btn.next');
    const progressFill = document.querySelector('.progress-fill');
    const currentCounter = document.querySelector('.slide-counter .current');
    const totalCounter = document.querySelector('.slide-counter .total');
    const heroSection = document.querySelector('.hero');

    if (!carouselContainer) return;

    // Get config or use defaults
    const config = window.CAROUSEL_CONFIG || {
        settings: {
            autoplay: true,
            autoplayDelay: 6000,
            transitionSpeed: 1000,
            pauseOnHover: true,
            enableKenBurns: true,
            enableSwipe: true,
            enableKeyboard: true,
        },
        slides: [],
        fallbackSlides: [
            { type: 'image', src: 'https://images.unsplash.com/photo-1504307651254-35680f356dfd?w=1920&q=80', alt: 'Construction Site' },
            { type: 'image', src: 'https://images.unsplash.com/photo-1590486803833-1c5dc8ddd4c8?w=1920&q=80', alt: 'Concrete Work' },
            { type: 'image', src: 'https://images.unsplash.com/photo-1541888946425-d81bb19240f5?w=1920&q=80', alt: 'Construction Equipment' },
            { type: 'image', src: 'https://images.unsplash.com/photo-1621905252472-943afaa20e20?w=1920&q=80', alt: 'Professional Construction' }
        ]
    };

    const settings = config.settings;
    
    // v1.2: Use getAllSlides() for auto-load from Google Drive with duplicate detection
    let slides = typeof config.getAllSlides === 'function' 
        ? config.getAllSlides() 
        : (config.slides.length > 0 ? config.slides : config.fallbackSlides);
    
    let currentSlide = 0;
    let progressInterval;
    let isPaused = false;
    const totalSlides = slides.length;
    const progressStep = 100 / (settings.autoplayDelay / 50);

    // ============================================
    // BUILD SLIDES DYNAMICALLY
    // ============================================
    function buildCarousel() {
        // Clear existing slides
        carouselContainer.innerHTML = '';

        slides.forEach(function(slide, index) {
            const slideElement = document.createElement('div');
            slideElement.className = 'hero-slide' + (index === 0 ? ' active' : '');
            slideElement.setAttribute('data-slide', index);

            if (slide.type === 'video') {
                // VIDEO SLIDE
                slideElement.innerHTML = `
                    <div class="slide-video-wrapper">
                        <video 
                            class="slide-video" 
                            ${slide.muted !== false ? 'muted' : ''} 
                            ${slide.loop !== false ? 'loop' : ''} 
                            playsinline
                            ${slide.poster ? 'poster="' + slide.poster + '"' : ''}
                        >
                            <source src="${slide.src}" type="video/${slide.src.split('.').pop()}">
                        </video>
                    </div>
                    <div class="slide-overlay"></div>
                `;
            } else {
                // IMAGE SLIDE
                slideElement.innerHTML = `
                    <div class="slide-bg ${settings.enableKenBurns ? 'ken-burns' : ''}" 
                         style="background-image: url('${slide.src}');"
                         role="img"
                         aria-label="${slide.alt || 'FPC Construction'}">
                    </div>
                    <div class="slide-overlay"></div>
                `;
            }

            carouselContainer.appendChild(slideElement);
        });

        // Update total counter
        if (totalCounter) {
            totalCounter.textContent = String(totalSlides).padStart(2, '0');
        }

        // Preload images for smooth transitions
        preloadMedia();
    }

    // ============================================
    // PRELOAD MEDIA
    // ============================================
    function preloadMedia() {
        slides.forEach(function(slide) {
            if (slide.type === 'image') {
                const img = new Image();
                img.src = slide.src;
                // Handle image load errors - switch to fallback
                img.onerror = function() {
                    console.warn('Failed to load image: ' + slide.src);
                };
            }
        });
    }

    // ============================================
    // GO TO SPECIFIC SLIDE
    // ============================================
    function goToSlide(index) {
        const allSlides = carouselContainer.querySelectorAll('.hero-slide');
        
        // Handle video on current slide
        const currentSlideEl = allSlides[currentSlide];
        if (currentSlideEl) {
            const currentVideo = currentSlideEl.querySelector('video');
            if (currentVideo) {
                currentVideo.pause();
                currentVideo.currentTime = 0;
            }
        }

        // Remove active class from all slides
        allSlides.forEach(function(slide) {
            slide.classList.remove('active');
        });

        // Update index with wrap-around
        currentSlide = index;
        if (currentSlide >= totalSlides) currentSlide = 0;
        if (currentSlide < 0) currentSlide = totalSlides - 1;

        // Add active class to new current slide
        const newSlideEl = allSlides[currentSlide];
        if (newSlideEl) {
            newSlideEl.classList.add('active');
            
            // Play video if it's a video slide
            const video = newSlideEl.querySelector('video');
            if (video) {
                video.play().catch(function(e) {
                    console.log('Video autoplay prevented:', e);
                });
            }
        }

        // Update counter
        if (currentCounter) {
            currentCounter.textContent = String(currentSlide + 1).padStart(2, '0');
        }

        // Reset progress
        resetProgress();
    }

    // ============================================
    // NAVIGATION FUNCTIONS
    // ============================================
    function nextSlide() {
        goToSlide(currentSlide + 1);
    }

    function prevSlide() {
        goToSlide(currentSlide - 1);
    }

    // ============================================
    // PROGRESS BAR ANIMATION
    // ============================================
    function startProgress() {
        if (!settings.autoplay || isPaused) return;

        let progress = 0;
        if (progressFill) progressFill.style.width = '0%';

        progressInterval = setInterval(function() {
            progress += progressStep;
            if (progressFill) progressFill.style.width = progress + '%';

            if (progress >= 100) {
                nextSlide();
            }
        }, 50);
    }

    function resetProgress() {
        clearInterval(progressInterval);
        if (progressFill) progressFill.style.width = '0%';
        if (!isPaused) startProgress();
    }

    function pauseAutoPlay() {
        isPaused = true;
        clearInterval(progressInterval);
    }

    function resumeAutoPlay() {
        isPaused = false;
        startProgress();
    }

    // ============================================
    // EVENT LISTENERS
    // ============================================
    
    // Navigation buttons
    if (prevBtn) {
        prevBtn.addEventListener('click', prevSlide);
    }

    if (nextBtn) {
        nextBtn.addEventListener('click', nextSlide);
    }

    // Keyboard navigation
    if (settings.enableKeyboard) {
        document.addEventListener('keydown', function(e) {
            if (e.key === 'ArrowLeft') prevSlide();
            if (e.key === 'ArrowRight') nextSlide();
        });
    }

    // Touch swipe support
    if (settings.enableSwipe && heroSection) {
        let touchStartX = 0;
        let touchEndX = 0;

        heroSection.addEventListener('touchstart', function(e) {
            touchStartX = e.changedTouches[0].screenX;
        }, { passive: true });

        heroSection.addEventListener('touchend', function(e) {
            touchEndX = e.changedTouches[0].screenX;
            handleSwipe();
        }, { passive: true });

        function handleSwipe() {
            const swipeThreshold = 50;
            const diff = touchStartX - touchEndX;

            if (Math.abs(diff) > swipeThreshold) {
                if (diff > 0) {
                    nextSlide();
                } else {
                    prevSlide();
                }
            }
        }
    }

    // Pause on hover
    if (settings.pauseOnHover && heroSection) {
        heroSection.addEventListener('mouseenter', pauseAutoPlay);
        heroSection.addEventListener('mouseleave', resumeAutoPlay);
    }

    // ============================================
    // INITIALIZE
    // ============================================
    buildCarousel();
    startProgress();

    // Log initialization
    console.log('%c FPC Carousel v1.2 Initialized ', 'background: #22c55e; color: #fff; padding: 4px 8px; border-radius: 4px;');
    console.log('%c Powered by mpowerio.ai ⚡ ', 'background: #d4a017; color: #000; padding: 4px 8px; border-radius: 4px;');
    console.log('Loaded ' + totalSlides + ' slides');
}

/**
 * Counter Animation
 */
function initCounterAnimation() {
    const counters = document.querySelectorAll('.stat-number[data-count]');

    if (counters.length === 0) return;

    const animateCounter = function(counter) {
        const target = parseInt(counter.getAttribute('data-count'));
        const duration = 2000;
        const step = target / (duration / 16);
        let current = 0;

        const updateCounter = function() {
            current += step;
            if (current < target) {
                counter.textContent = Math.floor(current);
                requestAnimationFrame(updateCounter);
            } else {
                counter.textContent = target;
            }
        };

        updateCounter();
    };

    // Intersection Observer for triggering animation
    const observer = new IntersectionObserver(function(entries) {
        entries.forEach(function(entry) {
            if (entry.isIntersecting) {
                animateCounter(entry.target);
                observer.unobserve(entry.target);
            }
        });
    }, { threshold: 0.5 });

    counters.forEach(function(counter) {
        observer.observe(counter);
    });
}

/**
 * Testimonial Slider
 */
function initTestimonialSlider() {
    const track = document.getElementById('testimonialsTrack');
    const cards = document.querySelectorAll('.testimonial-card');
    const prevBtn = document.querySelector('.testimonials-section .testimonial-btn.prev');
    const nextBtn = document.querySelector('.testimonials-section .testimonial-btn.next');
    const dotsContainer = document.querySelector('.testimonial-dots');

    if (!track || cards.length === 0) return;

    let currentIndex = 0;
    const totalCards = cards.length;

    // Create dots
    if (dotsContainer) {
        for (let i = 0; i < totalCards; i++) {
            const dot = document.createElement('div');
            dot.classList.add('testimonial-dot');
            if (i === 0) dot.classList.add('active');
            dot.addEventListener('click', function() {
                goToSlide(i);
            });
            dotsContainer.appendChild(dot);
        }
    }

    const dots = document.querySelectorAll('.testimonial-dot');

    function updateSlider() {
        track.style.transform = 'translateX(-' + (currentIndex * 100) + '%)';

        // Update dots
        dots.forEach(function(dot, index) {
            dot.classList.toggle('active', index === currentIndex);
        });
    }

    function goToSlide(index) {
        currentIndex = index;
        if (currentIndex >= totalCards) currentIndex = 0;
        if (currentIndex < 0) currentIndex = totalCards - 1;
        updateSlider();
    }

    function nextSlide() {
        goToSlide(currentIndex + 1);
    }

    function prevSlide() {
        goToSlide(currentIndex - 1);
    }

    // Event listeners
    if (prevBtn) prevBtn.addEventListener('click', prevSlide);
    if (nextBtn) nextBtn.addEventListener('click', nextSlide);

    // Auto-advance every 5 seconds
    setInterval(nextSlide, 5000);

    // Touch swipe support
    let touchStartX = 0;
    let touchEndX = 0;

    track.addEventListener('touchstart', function(e) {
        touchStartX = e.changedTouches[0].screenX;
    }, { passive: true });

    track.addEventListener('touchend', function(e) {
        touchEndX = e.changedTouches[0].screenX;
        const diff = touchStartX - touchEndX;
        if (Math.abs(diff) > 50) {
            if (diff > 0) nextSlide();
            else prevSlide();
        }
    }, { passive: true });
}

/**
 * Project Filter
 */
function initProjectFilter() {
    const filterBtns = document.querySelectorAll('.filter-btn');
    const projectCards = document.querySelectorAll('.project-card');

    if (filterBtns.length === 0 || projectCards.length === 0) return;

    filterBtns.forEach(function(btn) {
        btn.addEventListener('click', function() {
            // Update active button
            filterBtns.forEach(function(b) {
                b.classList.remove('active');
            });
            btn.classList.add('active');

            // Filter projects
            const filter = btn.getAttribute('data-filter');

            projectCards.forEach(function(card) {
                const category = card.getAttribute('data-category');

                if (filter === 'all' || category === filter) {
                    card.classList.remove('hidden');
                    card.style.animation = 'fadeIn 0.5s ease forwards';
                } else {
                    card.classList.add('hidden');
                }
            });
        });
    });
}

/**
 * FAQ Accordion
 */
function initFAQ() {
    const faqItems = document.querySelectorAll('.faq-item');

    faqItems.forEach(function(item) {
        const question = item.querySelector('.faq-question');

        if (question) {
            question.addEventListener('click', function() {
                const isActive = item.classList.contains('active');

                // Close all items
                faqItems.forEach(function(faq) {
                    faq.classList.remove('active');
                });

                // Open clicked item if it wasn't active
                if (!isActive) {
                    item.classList.add('active');
                }
            });
        }
    });
}

/**
 * Contact Form
 */
function initContactForm() {
    const form = document.getElementById('contactForm');

    if (!form) return;

    form.addEventListener('submit', function(e) {
        e.preventDefault();

        const submitBtn = form.querySelector('button[type="submit"]');
        const originalHTML = submitBtn.innerHTML;

        // Show loading state
        submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> <span>Sending...</span>';
        submitBtn.disabled = true;

        // Simulate form submission
        setTimeout(function() {
            // Show success message
            showNotification('Thank you! Your message has been sent successfully. We\'ll be in touch soon!', 'success');

            // Reset form
            form.reset();

            // Restore button
            submitBtn.innerHTML = originalHTML;
            submitBtn.disabled = false;
        }, 1500);
    });

    // Form validation feedback
    const inputs = form.querySelectorAll('input, select, textarea');

    inputs.forEach(function(input) {
        input.addEventListener('blur', function() {
            if (input.required && !input.value) {
                input.style.borderColor = '#ef4444';
            } else {
                input.style.borderColor = '';
            }
        });

        input.addEventListener('input', function() {
            input.style.borderColor = '';
        });
    });
}

/**
 * Notification Toast
 */
function showNotification(message, type) {
    // Remove existing notifications
    const existing = document.querySelector('.notification-toast');
    if (existing) existing.remove();

    // Create notification
    const notification = document.createElement('div');
    notification.className = 'notification-toast notification-' + type;
    notification.innerHTML = '<i class="fas ' + (type === 'success' ? 'fa-check-circle' : 'fa-exclamation-circle') + '"></i><span>' + message + '</span>';

    // Styles
    notification.style.cssText = 'position: fixed; top: 120px; right: 24px; background: ' + (type === 'success' ? '#22c55e' : '#ef4444') + '; color: white; padding: 16px 24px; border-radius: 12px; display: flex; align-items: center; gap: 12px; box-shadow: 0 10px 40px rgba(0,0,0,0.2); z-index: 10000; animation: slideIn 0.4s ease; max-width: 400px; font-size: 14px;';

    // Add animation styles
    if (!document.getElementById('notification-styles')) {
        const style = document.createElement('style');
        style.id = 'notification-styles';
        style.textContent = '@keyframes slideIn { from { transform: translateX(100%); opacity: 0; } to { transform: translateX(0); opacity: 1; } } @keyframes slideOut { from { transform: translateX(0); opacity: 1; } to { transform: translateX(100%); opacity: 0; } } @keyframes fadeIn { from { opacity: 0; transform: translateY(20px); } to { opacity: 1; transform: translateY(0); } }';
        document.head.appendChild(style);
    }

    document.body.appendChild(notification);

    // Remove after 5 seconds
    setTimeout(function() {
        notification.style.animation = 'slideOut 0.4s ease forwards';
        setTimeout(function() {
            notification.remove();
        }, 400);
    }, 5000);
}

/**
 * Back to Top Button
 */
function initBackToTop() {
    const backToTop = document.getElementById('backToTop');

    if (!backToTop) return;

    // Show/hide button based on scroll position
    window.addEventListener('scroll', function() {
        if (window.scrollY > 500) {
            backToTop.classList.add('visible');
        } else {
            backToTop.classList.remove('visible');
        }
    });

    // Scroll to top on click
    backToTop.addEventListener('click', function() {
        window.scrollTo({
            top: 0,
            behavior: 'smooth'
        });
    });
}

/**
 * Floating CTA Button
 */
function initFloatingCTA() {
    const floatingCTA = document.querySelector('.floating-cta');

    if (!floatingCTA) return;

    window.addEventListener('scroll', function() {
        if (window.scrollY > 800) {
            floatingCTA.classList.add('visible');
        } else {
            floatingCTA.classList.remove('visible');
        }
    });
}

/**
 * Smooth Scroll for anchor links
 */
function initSmoothScroll() {
    const links = document.querySelectorAll('a[href^="#"]');

    links.forEach(function(link) {
        link.addEventListener('click', function(e) {
            const href = this.getAttribute('href');

            if (href === '#') return;

            const target = document.querySelector(href);

            if (target) {
                e.preventDefault();

                const headerHeight = document.getElementById('header').offsetHeight;
                const targetPosition = target.offsetTop - headerHeight;

                window.scrollTo({
                    top: targetPosition,
                    behavior: 'smooth'
                });
            }
        });
    });
}

/**
 * Initialize AOS (Animate On Scroll)
 */
function initAOS() {
    if (typeof AOS !== 'undefined') {
        AOS.init({
            duration: 800,
            easing: 'ease-out-cubic',
            once: true,
            offset: 50,
            disable: 'mobile'
        });
    }
}

/**
 * Utility: Throttle function
 */
function throttle(func, limit) {
    let inThrottle;
    return function() {
        const args = arguments;
        const context = this;
        if (!inThrottle) {
            func.apply(context, args);
            inThrottle = true;
            setTimeout(function() {
                inThrottle = false;
            }, limit);
        }
    };
}

/**
 * Utility: Debounce function
 */
function debounce(func, wait) {
    let timeout;
    return function() {
        const context = this;
        const args = arguments;
        clearTimeout(timeout);
        timeout = setTimeout(function() {
            func.apply(context, args);
        }, wait);
    };
}

// Optimized scroll event handling
window.addEventListener('scroll', throttle(function() {
    // All scroll-based functionality is handled in their respective functions
}, 16));

// Handle window resize
window.addEventListener('resize', debounce(function() {
    // Reinitialize AOS on resize
    if (typeof AOS !== 'undefined') {
        AOS.refresh();
    }
}, 250));

// Console branding
console.log('%c FPC CONSTRUCTION v1.2 ', 'background: #d4a017; color: #000; padding: 10px 20px; font-size: 16px; font-weight: bold;');
console.log('%c Built with excellence - TB12 mentality ', 'color: #6b6b6b; font-size: 12px;');
console.log('%c Powered by mpowerio.ai ', 'background: #1a1a1a; color: #d4a017; padding: 4px 8px; font-size: 11px;');
console.log('%c "Qualified Inputs yielding Quantum Outputs!" ', 'color: #22c55e; font-style: italic;');
console.log('%c Solar Fusion level power for Small Businesses! ', 'color: #d4a017; font-weight: bold;');
