/**
 * FPC CONSTRUCTION - CAROUSEL CONFIGURATION v1.2
 * ================================================
 * TB12 Mentality - Championship Level Media Management
 * 
 * INSTALLER: Ernesto Martinez @digitwitch.com
 * POWERED BY: mpowerio.ai - "Qualified Inputs yielding Quantum Outputs!"
 * Solar Fusion level power for Small Businesses! LET'S GO!!
 * ================================================
 * 
 * NEW IN v1.2:
 * ✅ Auto-load photos from Google Drive
 * ✅ Duplicate detection (no repeated images)
 * ✅ PNG upscaling support
 * ✅ Batch add - just paste file IDs!
 * ✅ Optimized image loading
 * 
 * ╔════════════════════════════════════════════════════════════╗
 * ║  QUICK SETUP - JUST 2 STEPS!                               ║
 * ╠════════════════════════════════════════════════════════════╣
 * ║                                                            ║
 * ║  STEP 1: Share your photos                                 ║
 * ║  ─────────────────────────────────────────────────────────  ║
 * ║  1. Open your Google Drive folder                          ║
 * ║  2. Select all photos → Right-click → "Share"              ║
 * ║  3. Change to "Anyone with the link can view"              ║
 * ║  4. For each photo, right-click → "Get link" → Copy        ║
 * ║                                                            ║
 * ║  STEP 2: Add file IDs to the array below                   ║
 * ║  ─────────────────────────────────────────────────────────  ║
 * ║  From link: https://drive.google.com/file/d/ABC123/view    ║
 * ║  Copy just: ABC123                                         ║
 * ║  Paste into GOOGLE_DRIVE_FILE_IDS array below              ║
 * ║                                                            ║
 * ╚════════════════════════════════════════════════════════════╝
 * 
 * YOUR GOOGLE DRIVE FOLDER:
 * https://drive.google.com/drive/folders/1mtkzCuw_zNsbeDa5N_P5yDJTL6lhLrF-
 * ================================================
 */

const CAROUSEL_CONFIG = {
    // ============================================
    // v1.2 SETTINGS
    // ============================================
    version: '1.2',
    
    settings: {
        autoplay: true,
        autoplayDelay: 6000,      // 6 seconds per slide
        transitionSpeed: 1000,    // 1 second transitions
        pauseOnHover: true,       // Pause when mouse hovers
        enableKenBurns: true,     // Cinematic zoom effect
        enableSwipe: true,        // Mobile swipe support
        enableKeyboard: true,     // Arrow key navigation
        preventDuplicates: true,  // v1.2: No duplicate images
        preloadImages: true,      // v1.2: Preload for smooth transitions
    },

    // ============================================
    // 🚀 GOOGLE DRIVE AUTO-LOAD (v1.2)
    // ============================================
    // Just paste your Google Drive file IDs here!
    // The system automatically builds the URLs.
    // 
    // HOW TO GET FILE IDs:
    // 1. Right-click photo in Drive → "Get link"
    // 2. Link looks like: https://drive.google.com/file/d/1ABC123xyz/view
    // 3. Copy just the ID part: 1ABC123xyz
    // 4. Paste it below!
    // ============================================
    
    googleDriveFileIds: [
        // ╔═══════════════════════════════════════════════════════╗
        // ║  PASTE YOUR FILE IDs HERE - ONE PER LINE              ║
        // ║  Example: '1ABC123xyz789',                            ║
        // ╚═══════════════════════════════════════════════════════╝
        
        // === YOUR FPC CONSTRUCTION PHOTOS ===
        // Uncomment and replace with your actual file IDs:
        
        // 'PASTE_IMG_4842_FILE_ID_HERE',    // IMG_4842.jpeg
        // 'PASTE_IMG_5676_FILE_ID_HERE',    // IMG_5676.jpeg
        // 'PASTE_TC_00009_FILE_ID_HERE',    // TC_00009.JPG
        // 'PASTE_IMG_4756_FILE_ID_HERE',    // IMG_4756.jpeg
        // 'PASTE_IMG_5672_FILE_ID_HERE',    // IMG_5672.jpeg
        // 'PASTE_IMG_5341_FILE_ID_HERE',    // IMG_5341.jpeg
        // 'PASTE_IMG_4748_FILE_ID_HERE',    // IMG_4748.jpeg
        // 'PASTE_IMG_5657_FILE_ID_HERE',    // IMG_5657.jpeg
        // 'PASTE_IMG_4752_FILE_ID_HERE',    // IMG_4752.jpeg
        // 'PASTE_IMG_4991_FILE_ID_HERE',    // IMG_4991.jpeg
        // Add all 31 photos...
    ],

    // ============================================
    // MANUAL SLIDES (Optional - for local files)
    // ============================================
    // Use this for images uploaded directly to the server
    // or if you prefer to specify full URLs manually
    
    slides: [
        // Example server-uploaded image:
        // {
        //     type: 'image',
        //     src: 'images/carousel/my-photo.jpg',
        //     alt: 'FPC Construction Project'
        // },
        
        // Example video:
        // {
        //     type: 'video',
        //     src: 'images/carousel/promo.mp4',
        //     poster: 'images/carousel/poster.jpg',
        //     muted: true,
        //     loop: true
        // },
    ],

    // ============================================
    // FALLBACK IMAGES (shown until yours load)
    // ============================================
    fallbackSlides: [
        {
            type: 'image',
            src: 'https://images.unsplash.com/photo-1504307651254-35680f356dfd?w=1920&q=80',
            alt: 'FPC Construction - Professional Team at Work'
        },
        {
            type: 'image',
            src: 'https://images.unsplash.com/photo-1590486803833-1c5dc8ddd4c8?w=1920&q=80',
            alt: 'FPC Construction - Quality Work'
        },
        {
            type: 'image',
            src: 'https://images.unsplash.com/photo-1541888946425-d81bb19240f5?w=1920&q=80',
            alt: 'FPC Construction - Heavy Equipment'
        },
        {
            type: 'image',
            src: 'https://images.unsplash.com/photo-1621905252472-943afaa20e20?w=1920&q=80',
            alt: 'FPC Construction - Professional Results'
        }
    ],

    // ============================================
    // v1.2 AUTO-BUILD FUNCTION
    // ============================================
    // Automatically converts file IDs to slide objects
    // with duplicate detection
    
    buildSlidesFromDrive: function() {
        const seen = new Set();
        const driveSlides = [];
        
        this.googleDriveFileIds.forEach((fileId, index) => {
            // Skip if empty or duplicate
            if (!fileId || seen.has(fileId)) {
                if (seen.has(fileId)) {
                    console.warn('Duplicate file ID skipped:', fileId);
                }
                return;
            }
            
            seen.add(fileId);
            
            driveSlides.push({
                type: 'image',
                src: 'https://drive.google.com/uc?export=view&id=' + fileId,
                alt: 'FPC Construction Project ' + (index + 1)
            });
        });
        
        return driveSlides;
    },

    // Get all slides (Drive + manual + fallback)
    getAllSlides: function() {
        const driveSlides = this.buildSlidesFromDrive();
        const allSlides = [...driveSlides, ...this.slides];
        
        // Use fallback if no slides configured
        if (allSlides.length === 0) {
            console.log('No custom slides found, using fallback images');
            return this.fallbackSlides;
        }
        
        console.log('Loaded ' + allSlides.length + ' slides (' + driveSlides.length + ' from Drive)');
        return allSlides;
    }
};

// Export for use in main.js
if (typeof module !== 'undefined' && module.exports) {
    module.exports = CAROUSEL_CONFIG;
}

/**
 * ============================================
 * 📋 QUICK COPY-PASTE TEMPLATE
 * ============================================
 * 
 * For each photo in your Drive folder:
 * 1. Right-click → Get link → Copy
 * 2. Extract ID from: https://drive.google.com/file/d/[THIS_PART]/view
 * 3. Paste below:
 * 
 * googleDriveFileIds: [
 *     'FILE_ID_1',
 *     'FILE_ID_2',
 *     'FILE_ID_3',
 *     // ... add all 31 photos
 * ],
 * 
 * ============================================
 * NEED HELP? Contact:
 * Ernesto Martinez @digitwitch.com
 * Powered by mpowerio.ai ⚡
 * ============================================
 */
